package com.nit.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nit.entity.JobPosting;
import com.nit.repository.JobPostingRepository;

import java.util.List;

@Service
public class JobPostingService {

    @Autowired
    private JobPostingRepository repository;

    public JobPosting save(JobPosting jobPosting) {
        return repository.save(jobPosting);
    }

    public List<JobPosting> getAllJobPostings() {
        return repository.findAll();
    }

    public JobPosting getJobPostingById(Long id) {
        return repository.findById(id).orElse(null);
    }

    public void deleteJobPosting(Long id) {
        repository.deleteById(id);
    }

    public List<JobPosting> searchJobPostings(String keyword) {
        return repository.findByTitleContainingOrLocationContainingOrRequiredSkillsContaining(keyword, keyword, keyword);
    }
}
