package com.nit.entity;



import org.springframework.stereotype.Controller;

import jakarta.persistence.Entity;
import lombok.Data;
import jakarta.persistence.*;

import java.time.LocalDate;
import java.util.List;

@Entity
@Data

public class JobPosting {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    
    private String title;

    
    private String description;

    
    private String location;

    
    private String company;

   
    private String salaryRange;

    @ElementCollection
   
    private List<String> requiredSkills;

    private LocalDate applicationDeadline;

}
