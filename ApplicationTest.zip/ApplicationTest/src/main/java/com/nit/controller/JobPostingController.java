package com.nit.controller;

import org.hibernate.mapping.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.nit.entity.JobPosting;
import com.nit.service.JobPostingService;

@Controller
public class JobPostingController {

    @Autowired
    private JobPostingService service;

    @GetMapping("/")
    public String home(Model model) {
        model.addAttribute("jobPostings", service.getAllJobPostings());
        return "index";
    }

    @GetMapping("/add")
    public String addJobForm(Model model) {
        model.addAttribute("jobPosting", new JobPosting());
        return "add-job";
    }

    @PostMapping("/save")
    public String saveJob(@Validated @ModelAttribute("jobPosting") JobPosting jobPosting, BindingResult result) {
        if (result.hasErrors()) {
            return "add-job";
        }
        service.save(jobPosting);
        return "redirect:/";
    }

    @GetMapping("/edit/{id}")
    public String editJobForm(@PathVariable("id") Long id, Model model) {
        JobPosting jobPosting = service.getJobPostingById(id);
        model.addAttribute("jobPosting", jobPosting);
        return "edit-job";
    }

    @PostMapping("/update/{id}")
    public String updateJob(@PathVariable("id") Long id, @Validated @ModelAttribute("jobPosting") JobPosting jobPosting, BindingResult result) {
        if (result.hasErrors()) {
            return "edit-job";
        }
        service.save(jobPosting);
        return "redirect:/";
    }

    @GetMapping("/delete/{id}")
    public String deleteJob(@PathVariable("id") Long id) {
        service.deleteJobPosting(id);
        return "redirect:/";
    }

    @GetMapping("/search")
    public String searchJobs(@RequestParam("keyword") String keyword, Model model) {
        List jobPostings = (List) service.searchJobPostings(keyword);
        model.addAttribute("jobPostings", jobPostings);
        return "index";
    }
}